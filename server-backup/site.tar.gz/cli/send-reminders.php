#!/usr/bin/env php
<?php
/**
 * Oregon Tires — Appointment Reminder Cron Script
 *
 * Sends reminder emails to customers with appointments tomorrow.
 * Uses DB-driven bilingual templates (email_tpl_reminder_*) via sendAppointmentReminderEmail().
 * Only sends to appointments with status 'new', 'pending', or 'confirmed'.
 *
 * Usage:  php send-reminders.php
 * Cron:   0 18 * * * php /home/hiphopwo/public_html/---oregon.tires/cli/send-reminders.php >> /tmp/ot-reminders.log 2>&1
 *
 * Recommended: Run daily at 6 PM to remind for next-day appointments.
 */

declare(strict_types=1);

// CLI-only guard
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    exit('CLI only.');
}

// Bootstrap (loads .env, DB, helpers)
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/mail.php';
require_once __DIR__ . '/../includes/sms.php';
require_once __DIR__ . '/../includes/push.php';

$tomorrow = (new DateTime('tomorrow'))->format('Y-m-d');
$smsEnabled = !empty($_ENV['TWILIO_SID']);

echo "[" . date('Y-m-d H:i:s') . "] Sending reminders for appointments on {$tomorrow}\n";
echo "SMS reminders: " . ($smsEnabled ? "enabled" : "disabled") . "\n";

try {
    $db = getDB();

    // Find appointments for tomorrow that haven't been cancelled/completed
    // and haven't already received a reminder
    $stmt = $db->prepare(
        "SELECT id, first_name, last_name, email, phone, service, services,
                preferred_date, preferred_time, vehicle_year, vehicle_make,
                vehicle_model, language, notes,
                COALESCE(sms_reminder_sent, 0) as sms_reminder_sent,
                COALESCE(reminder_sent, 0) as reminder_sent
         FROM oretir_appointments
         WHERE preferred_date = ?
           AND status IN ('new', 'pending', 'confirmed')
           AND ((reminder_sent IS NULL OR reminder_sent = 0) OR (sms_reminder_sent IS NULL OR sms_reminder_sent = 0))
         ORDER BY preferred_time ASC"
    );
    $stmt->execute([$tomorrow]);
    $appointments = $stmt->fetchAll();

    if (empty($appointments)) {
        echo "No appointments to remind.\n";
        exit(0);
    }

    echo "Found " . count($appointments) . " appointment(s) to remind.\n";

    $emailSent = 0;
    $emailFailed = 0;
    $smsSent = 0;
    $smsFailed = 0;

    foreach ($appointments as $appt) {
        // Send email reminder if not already sent
        if (empty($appt['reminder_sent'])) {
            $success = sendAppointmentReminderEmail($appt);

            if ($success) {
                $emailSent++;
                $db->prepare("UPDATE oretir_appointments SET reminder_sent = 1 WHERE id = ?")
                   ->execute([$appt['id']]);
                echo "  ✓ Email reminder sent to {$appt['email']} (#{$appt['id']})\n";
            } else {
                $emailFailed++;
                echo "  ✗ Email FAILED for {$appt['email']} (#{$appt['id']})\n";
            }
        }

        // Queue push notification reminder
        try {
            $svcs = !empty($appt['services']) ? (json_decode($appt['services'], true) ?: [$appt['service']]) : [$appt['service']];
            $serviceDisplay = implode(' + ', array_map(fn(string $s) => ucwords(str_replace('-', ' ', $s)), $svcs));
            $pushTime = formatTimeDisplay($appt['preferred_time']);
            $subs = findPushSubscriptionsByEmail($appt['email']);
            if (!empty($subs)) {
                $custId = (int) ($subs[0]['customer_id'] ?? 0);
                if ($custId > 0) {
                    queueNotificationForCustomer(
                        $custId,
                        'appointment_reminder',
                        "Reminder: {$serviceDisplay} Tomorrow",
                        "Recordatorio: {$serviceDisplay} Ma\u00f1ana",
                        "Your {$serviceDisplay} appointment is tomorrow at {$pushTime}. Oregon Tires Auto Care.",
                        "Su cita de {$serviceDisplay} es ma\u00f1ana a las {$pushTime}. Oregon Tires Auto Care.",
                        '/members?tab=bookings'
                    );
                }
                echo "  \u2713 Push reminder queued for {$appt['email']}\n";
            }
        } catch (\Throwable $pushErr) {
            error_log("send-reminders.php: push queue failed for #{$appt['id']}: " . $pushErr->getMessage());
        }

        // Send SMS reminder if enabled and not already sent
        if ($smsEnabled && empty($appt['sms_reminder_sent']) && !empty($appt['phone'])) {
            try {
                $smsSvcs = !empty($appt['services']) ? (json_decode($appt['services'], true) ?: [$appt['service']]) : [$appt['service']];
                $serviceDisplay = implode(' + ', array_map(fn(string $s) => ucwords(str_replace('-', ' ', $s)), $smsSvcs));

                // Format time for SMS
                $smsTime = formatTimeDisplay($appt['preferred_time']);

                $apptLang = ($appt['language'] ?? 'english') === 'spanish' ? 'es' : 'en';

                if ($apptLang === 'es') {
                    $smsMessage = "Oregon Tires: Recordatorio - su cita de {$serviceDisplay} es manana a las {$smsTime}. Llame al (503) 367-9714 para reprogramar.";
                } else {
                    $smsMessage = "Oregon Tires: Reminder - your {$serviceDisplay} appointment is tomorrow at {$smsTime}. Call (503) 367-9714 to reschedule.";
                }

                $smsResult = sendSMS($appt['phone'], $smsMessage);

                if ($smsResult) {
                    $smsSent++;
                    $db->prepare("UPDATE oretir_appointments SET sms_reminder_sent = 1 WHERE id = ?")
                       ->execute([$appt['id']]);
                    logSMS('appointment_reminder', "SMS reminder sent to {$appt['phone']} for appointment #{$appt['id']}");
                    echo "  ✓ SMS reminder sent to {$appt['phone']} (#{$appt['id']})\n";
                } else {
                    $smsFailed++;
                    logSMS('appointment_reminder_failed', "SMS reminder FAILED for {$appt['phone']} appointment #{$appt['id']}");
                    echo "  ✗ SMS FAILED for {$appt['phone']} (#{$appt['id']})\n";
                }
            } catch (\Throwable $e) {
                $smsFailed++;
                error_log("send-reminders.php: SMS error for #{$appt['id']}: " . $e->getMessage());
                echo "  ✗ SMS ERROR for {$appt['phone']} (#{$appt['id']}): {$e->getMessage()}\n";
            }
        }
    }

    echo "\nCustomer reminders: Email {$emailSent} sent / {$emailFailed} failed";
    if ($smsEnabled) {
        echo ", SMS {$smsSent} sent / {$smsFailed} failed";
    }
    echo ".\n";

    // ─── Employee/Admin Reminders ──────────────────────────────────────────
    // Send a daily summary to each employee with tomorrow's assigned appointments
    // and a summary to the admin/office contact
    try {
        $empSent = 0;

        // Get tomorrow's appointments grouped by assigned employee
        $empApptStmt = $db->prepare(
            "SELECT a.id, a.service, a.services, a.preferred_time, a.first_name, a.last_name,
                    a.vehicle_year, a.vehicle_make, a.vehicle_model,
                    e.id as emp_id, e.name as emp_name, e.email as emp_email
             FROM oretir_appointments a
             LEFT JOIN oretir_employees e ON a.assigned_employee_id = e.id AND e.is_active = 1
             WHERE a.preferred_date = ?
               AND a.status IN ('new', 'pending', 'confirmed')
             ORDER BY a.preferred_time ASC"
        );
        $empApptStmt->execute([$tomorrow]);
        $tomorrowAppts = $empApptStmt->fetchAll(\PDO::FETCH_ASSOC);

        if (!empty($tomorrowAppts)) {
            // Group by employee
            $byEmployee = [];
            foreach ($tomorrowAppts as $a) {
                $key = $a['emp_id'] ? (int) $a['emp_id'] : 0;
                $byEmployee[$key][] = $a;
            }

            // Send to each assigned employee
            foreach ($byEmployee as $empId => $empAppts) {
                if ($empId === 0) continue; // unassigned
                $empEmail = $empAppts[0]['emp_email'] ?? '';
                $empName  = $empAppts[0]['emp_name'] ?? 'Team Member';
                if (empty($empEmail)) continue;

                $count = count($empAppts);
                $lines = [];
                foreach ($empAppts as $ea) {
                    $eaSvcs = !empty($ea['services']) ? (json_decode($ea['services'], true) ?: [$ea['service']]) : [$ea['service']];
                    $svc = implode(' + ', array_map(fn(string $s) => ucwords(str_replace('-', ' ', $s)), $eaSvcs));
                    $vehicle = trim(($ea['vehicle_year'] ?? '') . ' ' . ($ea['vehicle_make'] ?? '') . ' ' . ($ea['vehicle_model'] ?? ''));
                    $lines[] = "  • " . formatTimeDisplay($ea['preferred_time']) . " — {$svc} — {$ea['first_name']} {$ea['last_name']}" . ($vehicle ? " ({$vehicle})" : '');
                }
                $body = "Hi {$empName},\n\nYou have {$count} appointment(s) scheduled for tomorrow ({$tomorrow}):\n\n" . implode("\n", $lines) . "\n\nOregon Tires Auto Care";

                $empMail = sendMail(
                    $empEmail,
                    "Tomorrow's Schedule: {$count} appointment(s) — Oregon Tires",
                    nl2br(htmlspecialchars($body)),
                    $body
                );
                if ($empMail) {
                    $empSent++;
                    echo "  ✓ Employee reminder sent to {$empName} ({$empEmail}) — {$count} appts\n";
                }
            }

            // Send summary to admin/office
            $adminEmail = $_ENV['CONTACT_EMAIL'] ?? '';
            if ($adminEmail) {
                $totalCount = count($tomorrowAppts);
                $unassigned = count($byEmployee[0] ?? []);
                $lines = [];
                foreach ($tomorrowAppts as $a) {
                    $aSvcs = !empty($a['services']) ? (json_decode($a['services'], true) ?: [$a['service']]) : [$a['service']];
                    $svc = implode(' + ', array_map(fn(string $s) => ucwords(str_replace('-', ' ', $s)), $aSvcs));
                    $emp = $a['emp_name'] ?? 'Unassigned';
                    $lines[] = "  • " . formatTimeDisplay($a['preferred_time']) . " — {$svc} — {$a['first_name']} {$a['last_name']} → {$emp}";
                }
                $body = "Oregon Tires — Tomorrow's Schedule ({$tomorrow})\n\n{$totalCount} appointment(s)" . ($unassigned ? " ({$unassigned} unassigned)" : '') . ":\n\n" . implode("\n", $lines);

                $adminMail = sendMail(
                    $adminEmail,
                    "Tomorrow: {$totalCount} appointment(s) — Oregon Tires",
                    nl2br(htmlspecialchars($body)),
                    $body
                );
                if ($adminMail) {
                    $empSent++;
                    echo "  ✓ Admin daily summary sent to {$adminEmail}\n";
                }
            }
        } else {
            // Notify admin if no appointments tomorrow
            $adminEmail = $_ENV['CONTACT_EMAIL'] ?? '';
            if ($adminEmail) {
                sendMail(
                    $adminEmail,
                    "No appointments scheduled for {$tomorrow} — Oregon Tires",
                    "<p>No appointments are currently scheduled for {$tomorrow}.</p>",
                    "No appointments are currently scheduled for {$tomorrow}."
                );
                echo "  ✓ No-appointments notice sent to admin\n";
                $empSent++;
            }
        }

        echo "Employee/admin reminders: {$empSent} sent.\n";
    } catch (\Throwable $empErr) {
        echo "  ✗ Employee reminder error: " . $empErr->getMessage() . "\n";
        error_log("send-reminders.php employee reminders: " . $empErr->getMessage());
    }

} catch (\Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    error_log("Oregon Tires send-reminders.php error: " . $e->getMessage());
    exit(1);
}
