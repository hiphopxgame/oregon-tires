<?php
/**
 * Oregon Tires — VIN Decode Service
 * Uses NHTSA vPIC API (free, no auth required)
 * Results cached permanently in oretir_vin_cache
 */

declare(strict_types=1);

/**
 * Decode a VIN using NHTSA vPIC API with permanent DB caching.
 *
 * @param string $vin 17-character VIN
 * @param PDO|null $db Optional PDO connection (uses getDB() if null)
 * @return array{success: bool, data?: array, error?: string}
 */
function decodeVin(string $vin, ?PDO $db = null): array
{
    $vin = strtoupper(trim($vin));

    if (!isValidVinFormat($vin)) {
        return ['success' => false, 'error' => 'Invalid VIN format. Must be 17 alphanumeric characters (no I, O, or Q).'];
    }

    $db = $db ?? getDB();

    // Check cache first
    $cached = getVinFromCache($vin, $db);
    if ($cached !== null) {
        return ['success' => true, 'data' => $cached, 'cached' => true];
    }

    // Call NHTSA vPIC API
    try {
        $url = 'https://vpic.nhtsa.dot.gov/api/vehicles/decodevinvalues/' . urlencode($vin) . '?format=json';

        $ctx = stream_context_create([
            'http' => [
                'timeout' => 10,
                'user_agent' => 'OregonTires/1.0',
            ],
        ]);

        $response = @file_get_contents($url, false, $ctx);
        if ($response === false) {
            return ['success' => false, 'error' => 'Unable to reach VIN decode service. Please try again.'];
        }

        $json = json_decode($response, true);
        if (!$json || empty($json['Results'][0])) {
            return ['success' => false, 'error' => 'Invalid response from VIN decode service.'];
        }

        $result = $json['Results'][0];

        // Check for errors from NHTSA
        $errorCode = (int) ($result['ErrorCode'] ?? 0);
        $errorText = $result['ErrorText'] ?? '';
        if ($errorCode >= 400) {
            return ['success' => false, 'error' => 'VIN not found or invalid: ' . $errorText];
        }

        // Extract key fields
        $decoded = extractVinFields($result);

        // Validate we got meaningful data
        if (empty($decoded['make']) && empty($decoded['model'])) {
            return ['success' => false, 'error' => 'VIN could not be decoded. Please verify and try again.'];
        }

        // Cache permanently
        cacheVinResult($vin, $response, $decoded, $db);

        return ['success' => true, 'data' => $decoded, 'cached' => false];

    } catch (\Throwable $e) {
        error_log("Oregon Tires VIN decode error for {$vin}: " . $e->getMessage());
        return ['success' => false, 'error' => 'VIN decode service error. Please try again later.'];
    }
}

/**
 * Validate VIN format (17 chars, no I/O/Q).
 */
function isValidVinFormat(string $vin): bool
{
    return (bool) preg_match('/^[A-HJ-NPR-Z0-9]{17}$/i', $vin);
}

/**
 * Extract relevant fields from NHTSA vPIC response.
 */
function extractVinFields(array $result): array
{
    return [
        'year'          => trim($result['ModelYear'] ?? ''),
        'make'          => trim($result['Make'] ?? ''),
        'model'         => trim($result['Model'] ?? ''),
        'trim_level'    => trim($result['Trim'] ?? ''),
        'engine'        => buildEngineString($result),
        'transmission'  => trim($result['TransmissionStyle'] ?? ''),
        'drive_type'    => trim($result['DriveType'] ?? ''),
        'body_class'    => trim($result['BodyClass'] ?? ''),
        'doors'         => trim($result['Doors'] ?? ''),
        'fuel_type'     => trim($result['FuelTypePrimary'] ?? ''),
        'plant_country' => trim($result['PlantCountry'] ?? ''),
        'vehicle_type'  => trim($result['VehicleType'] ?? ''),
    ];
}

/**
 * Build a human-readable engine string from NHTSA data.
 */
function buildEngineString(array $result): string
{
    $parts = array_filter([
        trim($result['DisplacementL'] ?? '') ? trim($result['DisplacementL']) . 'L' : '',
        trim($result['EngineCylinders'] ?? '') ? trim($result['EngineCylinders']) . '-cyl' : '',
        trim($result['FuelTypePrimary'] ?? ''),
        trim($result['EngineHP'] ?? '') ? trim($result['EngineHP']) . 'hp' : '',
    ]);
    return implode(' ', $parts) ?: trim($result['EngineModel'] ?? '');
}

/**
 * Get decoded VIN data from cache.
 */
function getVinFromCache(string $vin, PDO $db): ?array
{
    $stmt = $db->prepare('SELECT * FROM oretir_vin_cache WHERE vin = ? LIMIT 1');
    $stmt->execute([$vin]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        return null;
    }

    return [
        'year'          => $row['year'] ?? '',
        'make'          => $row['make'] ?? '',
        'model'         => $row['model'] ?? '',
        'trim_level'    => $row['trim_level'] ?? '',
        'engine'        => $row['engine'] ?? '',
        'transmission'  => $row['transmission'] ?? '',
        'drive_type'    => $row['drive_type'] ?? '',
        'body_class'    => $row['body_class'] ?? '',
        'doors'         => $row['doors'] ?? '',
        'fuel_type'     => $row['fuel_type'] ?? '',
        'plant_country' => $row['plant_country'] ?? '',
        'vehicle_type'  => $row['vehicle_type'] ?? '',
    ];
}

/**
 * Cache VIN decode result permanently.
 */
function cacheVinResult(string $vin, string $rawJson, array $decoded, PDO $db): void
{
    try {
        $stmt = $db->prepare(
            'INSERT INTO oretir_vin_cache
                (vin, raw_json, year, make, model, trim_level, engine, transmission,
                 drive_type, body_class, doors, fuel_type, plant_country, vehicle_type, cached_at)
             VALUES
                (:vin, :raw_json, :year, :make, :model, :trim_level, :engine, :transmission,
                 :drive_type, :body_class, :doors, :fuel_type, :plant_country, :vehicle_type, NOW())
             ON DUPLICATE KEY UPDATE vin = vin'
        );
        $stmt->execute([
            ':vin'           => $vin,
            ':raw_json'      => $rawJson,
            ':year'          => $decoded['year'] ?: null,
            ':make'          => $decoded['make'] ?: null,
            ':model'         => $decoded['model'] ?: null,
            ':trim_level'    => $decoded['trim_level'] ?: null,
            ':engine'        => $decoded['engine'] ?: null,
            ':transmission'  => $decoded['transmission'] ?: null,
            ':drive_type'    => $decoded['drive_type'] ?: null,
            ':body_class'    => $decoded['body_class'] ?: null,
            ':doors'         => $decoded['doors'] ?: null,
            ':fuel_type'     => $decoded['fuel_type'] ?: null,
            ':plant_country' => $decoded['plant_country'] ?: null,
            ':vehicle_type'  => $decoded['vehicle_type'] ?: null,
        ]);
    } catch (\Throwable $e) {
        error_log("Oregon Tires VIN cache error for {$vin}: " . $e->getMessage());
    }
}

/**
 * Find or create a customer record from booking data.
 *
 * @return int|null Customer ID or null on failure
 */
function findOrCreateCustomer(string $email, string $firstName, string $lastName, string $phone, string $language, ?PDO $db = null): ?int
{
    $db = $db ?? getDB();

    try {
        $stmt = $db->prepare('SELECT id FROM oretir_customers WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            $db->prepare(
                'UPDATE oretir_customers SET first_name = ?, last_name = ?, phone = ?, language = ?,
                 updated_at = NOW() WHERE id = ?'
            )->execute([$firstName, $lastName, $phone, $language, $existing['id']]);
            return (int) $existing['id'];
        }

        $stmt = $db->prepare(
            'INSERT INTO oretir_customers (first_name, last_name, email, phone, language, visit_count, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, 0, NOW(), NOW())'
        );
        $stmt->execute([$firstName, $lastName, $email, $phone, $language]);
        return (int) $db->lastInsertId();

    } catch (\Throwable $e) {
        error_log("Oregon Tires findOrCreateCustomer error: " . $e->getMessage());
        return null;
    }
}

/**
 * Find or create a vehicle record from booking data.
 *
 * @return int|null Vehicle ID or null on failure
 */
function findOrCreateVehicle(int $customerId, ?string $year, ?string $make, ?string $model, ?string $vin = null, ?PDO $db = null, array $specs = []): ?int
{
    $db = $db ?? getDB();

    if (empty($year) && empty($make) && empty($model) && empty($vin)) {
        return null;
    }

    // Spec fields that can be populated from VIN decode
    $specCols = ['trim_level', 'engine', 'transmission', 'drive_type', 'body_class', 'doors', 'fuel_type', 'license_plate'];

    try {
        if (!empty($vin)) {
            $stmt = $db->prepare('SELECT id, engine FROM oretir_vehicles WHERE vin = ? AND customer_id = ? LIMIT 1');
            $stmt->execute([$vin, $customerId]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($existing) {
                // Backfill specs if vehicle exists but has no factory data
                if (empty($existing['engine']) && !empty($specs)) {
                    $sets = ['updated_at = NOW()'];
                    $vals = [];
                    foreach ($specCols as $col) {
                        if (!empty($specs[$col])) {
                            $sets[] = "$col = ?";
                            $vals[] = $specs[$col];
                        }
                    }
                    if (count($vals) > 0) {
                        $vals[] = $existing['id'];
                        $db->prepare('UPDATE oretir_vehicles SET ' . implode(', ', $sets) . ' WHERE id = ?')
                           ->execute($vals);
                    }
                }
                return (int) $existing['id'];
            }
        }

        if (!empty($year) && !empty($make) && !empty($model)) {
            $stmt = $db->prepare(
                'SELECT id, engine FROM oretir_vehicles WHERE customer_id = ? AND year = ? AND make = ? AND model = ? LIMIT 1'
            );
            $stmt->execute([$customerId, $year, $make, $model]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($existing) {
                // Backfill VIN + specs if missing
                $sets = ['updated_at = NOW()'];
                $vals = [];
                if (!empty($vin)) {
                    $sets[] = 'vin = ?';
                    $vals[] = $vin;
                }
                if (empty($existing['engine'])) {
                    foreach ($specCols as $col) {
                        if (!empty($specs[$col])) {
                            $sets[] = "$col = ?";
                            $vals[] = $specs[$col];
                        }
                    }
                }
                if (count($vals) > 0) {
                    $vals[] = $existing['id'];
                    $db->prepare('UPDATE oretir_vehicles SET ' . implode(', ', $sets) . ' WHERE id = ?')
                       ->execute($vals);
                }
                return (int) $existing['id'];
            }
        }

        // Build INSERT with all available spec fields
        $cols = ['customer_id', 'vin', 'year', 'make', 'model'];
        $vals = [$customerId, $vin ?: null, $year ?: null, $make ?: null, $model ?: null];
        foreach ($specCols as $col) {
            if (!empty($specs[$col])) {
                $cols[] = $col;
                $vals[] = $specs[$col];
            }
        }
        $placeholders = implode(', ', array_fill(0, count($cols), '?'));
        $colNames = implode(', ', $cols);

        $stmt = $db->prepare(
            "INSERT INTO oretir_vehicles ({$colNames}, created_at, updated_at)
             VALUES ({$placeholders}, NOW(), NOW())"
        );
        $stmt->execute($vals);
        return (int) $db->lastInsertId();

    } catch (\Throwable $e) {
        error_log("Oregon Tires findOrCreateVehicle error: " . $e->getMessage());
        return null;
    }
}

/**
 * Generate a unique RO number (RO-XXXXXXXX format).
 */
function generateRoNumber(?PDO $db = null): string
{
    $db = $db ?? getDB();
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $maxAttempts = 10;

    for ($attempt = 0; $attempt < $maxAttempts; $attempt++) {
        $code = '';
        $bytes = random_bytes(8);
        for ($i = 0; $i < 8; $i++) {
            $code .= $chars[ord($bytes[$i]) % strlen($chars)];
        }
        $candidate = 'RO-' . $code;

        $stmt = $db->prepare('SELECT COUNT(*) FROM oretir_repair_orders WHERE ro_number = ?');
        $stmt->execute([$candidate]);
        if ((int) $stmt->fetchColumn() === 0) {
            return $candidate;
        }
    }

    throw new \RuntimeException('Failed to generate unique RO number after ' . $maxAttempts . ' attempts');
}

/**
 * Generate a unique estimate number (ES-XXXXXXXX format).
 */
function generateEstimateNumber(?PDO $db = null): string
{
    $db = $db ?? getDB();
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $maxAttempts = 10;

    for ($attempt = 0; $attempt < $maxAttempts; $attempt++) {
        $code = '';
        $bytes = random_bytes(8);
        for ($i = 0; $i < 8; $i++) {
            $code .= $chars[ord($bytes[$i]) % strlen($chars)];
        }
        $candidate = 'ES-' . $code;

        $stmt = $db->prepare('SELECT COUNT(*) FROM oretir_estimates WHERE estimate_number = ?');
        $stmt->execute([$candidate]);
        if ((int) $stmt->fetchColumn() === 0) {
            return $candidate;
        }
    }

    throw new \RuntimeException('Failed to generate unique estimate number after ' . $maxAttempts . ' attempts');
}

/**
 * Auto-create a Repair Order for a given appointment.
 *
 * @return array{id: int, ro_number: string, existing: bool}|null
 */
function createRoForAppointment(int $appointmentId, PDO $db): ?array
{
    // Fetch appointment
    $stmt = $db->prepare('SELECT * FROM oretir_appointments WHERE id = ? LIMIT 1');
    $stmt->execute([$appointmentId]);
    $appt = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$appt || $appt['status'] === 'cancelled') {
        return null;
    }

    // Check if RO already exists for this appointment
    $roCheck = $db->prepare('SELECT id, ro_number FROM oretir_repair_orders WHERE appointment_id = ? LIMIT 1');
    $roCheck->execute([$appointmentId]);
    $existing = $roCheck->fetch(PDO::FETCH_ASSOC);
    if ($existing) {
        return ['id' => (int) $existing['id'], 'ro_number' => $existing['ro_number'], 'existing' => true];
    }

    // Can't create RO without a customer
    if (empty($appt['customer_id'])) {
        return null;
    }

    $roNumber = generateRoNumber($db);

    // Build customer concern from services + notes
    $concern = $appt['notes'] ?? '';
    $servicesJson = $appt['services'] ?? null;
    if ($servicesJson) {
        $servicesList = json_decode($servicesJson, true);
        if (is_array($servicesList) && count($servicesList) > 0) {
            $serviceLabels = implode(' + ', array_map(fn(string $s) => ucwords(str_replace('-', ' ', $s)), $servicesList));
            $concern = $serviceLabels . ($concern ? "\n" . $concern : '');
        }
    } elseif (!empty($appt['service'])) {
        $concern = ucwords(str_replace('-', ' ', $appt['service'])) . ($concern ? "\n" . $concern : '');
    }

    // Transfer appointment admin_notes to RO admin_notes
    $roAdminNotes = null;
    if (!empty($appt['admin_notes'])) {
        $roAdminNotes = "[From Appointment]\n" . $appt['admin_notes'];
    }

    $stmt = $db->prepare(
        'INSERT INTO oretir_repair_orders
            (ro_number, customer_id, vehicle_id, appointment_id, status,
             customer_concern, service_location, service_distance_miles,
             admin_notes, promised_date, promised_time, assigned_employee_id, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())'
    );
    $stmt->execute([
        $roNumber,
        (int) $appt['customer_id'],
        $appt['vehicle_id'] ? (int) $appt['vehicle_id'] : null,
        $appointmentId,
        'intake',
        $concern ?: null,
        $appt['service_location'] ?? null,
        $appt['service_distance_miles'] ?? null,
        $roAdminNotes,
        $appt['preferred_date'] ?? null,
        $appt['preferred_time'] ?? null,
        $appt['assigned_employee_id'] ?? null,
    ]);

    return ['id' => (int) $db->lastInsertId(), 'ro_number' => $roNumber, 'existing' => false];
}

/**
 * Bidirectional status sync between appointments and repair orders.
 *
 * @param string $entity  'appointment' or 'ro'
 * @param int    $entityId  The ID of the entity whose status just changed
 * @param string $newStatus The new status value
 */
function syncAppointmentRoStatus(string $entity, int $entityId, string $newStatus, PDO $db): void
{
    try {
        if ($entity === 'appointment') {
            // Appointment → RO: cascade cancellation
            if ($newStatus === 'cancelled') {
                $db->prepare(
                    "UPDATE oretir_repair_orders
                     SET status = 'cancelled', updated_at = NOW()
                     WHERE appointment_id = ? AND status NOT IN ('completed', 'invoiced')"
                )->execute([$entityId]);
            }
        } elseif ($entity === 'ro') {
            // RO → Appointment: keep appointment status aligned with RO progress
            $roStmt = $db->prepare('SELECT appointment_id FROM oretir_repair_orders WHERE id = ? LIMIT 1');
            $roStmt->execute([$entityId]);
            $ro = $roStmt->fetch(PDO::FETCH_ASSOC);
            if (!$ro || empty($ro['appointment_id'])) {
                return;
            }
            $apptId = (int) $ro['appointment_id'];

            // Auto-confirm appointment when RO progresses past intake
            // check_in, diagnosis, estimate_pending, pending_approval, approved, in_progress, ready
            $confirmStatuses = ['check_in', 'diagnosis', 'estimate_pending', 'pending_approval', 'approved', 'in_progress', 'ready'];
            if (in_array($newStatus, $confirmStatuses, true)) {
                $db->prepare(
                    "UPDATE oretir_appointments SET status = 'confirmed', updated_at = NOW()
                     WHERE id = ? AND status IN ('new', 'pending')"
                )->execute([$apptId]);
            }

            // Mark appointment completed when RO reaches completed, invoiced, or ready
            if (in_array($newStatus, ['completed', 'invoiced'], true)) {
                $db->prepare(
                    "UPDATE oretir_appointments SET status = 'completed', updated_at = NOW()
                     WHERE id = ? AND status NOT IN ('completed', 'cancelled')"
                )->execute([$apptId]);
            }

            // Cancel appointment when RO is cancelled
            if ($newStatus === 'cancelled') {
                $db->prepare(
                    "UPDATE oretir_appointments SET status = 'cancelled', updated_at = NOW()
                     WHERE id = ? AND status NOT IN ('completed', 'cancelled')"
                )->execute([$apptId]);
            }
        }
    } catch (\Throwable $e) {
        error_log("syncAppointmentRoStatus error ({$entity} #{$entityId} → {$newStatus}): " . $e->getMessage());
    }
}
