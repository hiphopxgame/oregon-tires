/**
 * Oregon Tires — Admin Promotions Manager
 * Handles CRUD for promotions (homepage banners + exit-intent popup).
 */

(function() {
  'use strict';

  function t(key, fallback) {
    return (typeof adminT !== 'undefined' && adminT[currentLang] && adminT[currentLang][key]) || fallback;
  }

  const API = '/api/admin/promotions.php';
  let promotions = [];
  let editingId = null;

  function getCsrf() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute('content') : '';
  }

  // ─── Toggle exit-intent vs banner fields ────────────────────
  function toggleExitIntentFields() {
    var placement = document.getElementById('promo-placement').value;
    var isExit = placement === 'exit_intent';
    var exitFields = document.getElementById('exit-intent-fields');
    var bannerFields = document.querySelectorAll('.banner-only-field');

    if (exitFields) {
      exitFields.classList.toggle('hidden', !isExit);
    }
    bannerFields.forEach(function(el) {
      el.classList.toggle('hidden', isExit);
    });
    updatePreview();
  }

  // ─── Load promotions ──────────────────────────────────────────
  async function loadPromotions() {
    try {
      const res = await fetch(API, { credentials: 'include' });
      const json = await res.json();
      if (json.success) {
        promotions = json.data || [];
      } else {
        promotions = [];
      }
      renderPromotionsTable();
    } catch (err) {
      console.error('loadPromotions error:', err);
      if (typeof showToast === 'function') showToast(t('promoLoadFail', 'Failed to load promotions'), true);
    }
  }

  // ─── Render table ─────────────────────────────────────────────
  function renderPromotionsTable() {
    const container = document.getElementById('promotions-table-body');
    if (!container) return;

    container.textContent = '';

    if (!promotions.length) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 8;
      td.className = 'text-center py-8 text-gray-400 dark:text-gray-500';
      td.textContent = t('promoNoPromos', 'No promotions yet. Click "New Promotion" to create one.');
      tr.appendChild(td);
      container.appendChild(tr);
      return;
    }

    promotions.forEach(function(promo) {
      const tr = document.createElement('tr');
      tr.className = 'border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50';

      // Title cell
      const tdTitle = document.createElement('td');
      tdTitle.className = 'px-4 py-3';
      const titleText = document.createElement('div');
      titleText.className = 'font-medium text-sm dark:text-gray-200';
      titleText.textContent = promo.title_en || '(untitled)';
      tdTitle.appendChild(titleText);
      if (promo.title_es) {
        var titleEs = document.createElement('div');
        titleEs.className = 'text-xs text-gray-400 dark:text-gray-500 mt-0.5';
        titleEs.textContent = promo.title_es.length > 60 ? promo.title_es.substring(0, 60) + '...' : promo.title_es;
        tdTitle.appendChild(titleEs);
      }
      var badgeText = promo.badge_text_en || promo.badge_text || '';
      if (badgeText) {
        const badge = document.createElement('span');
        badge.className = 'inline-block mt-1 text-xs px-2 py-0.5 rounded-full font-bold';
        badge.style.backgroundColor = promo.bg_color || '#f59e0b';
        badge.style.color = promo.text_color || '#000';
        badge.textContent = badgeText;
        tdTitle.appendChild(badge);
      }
      tr.appendChild(tdTitle);

      // Type cell
      const tdType = document.createElement('td');
      tdType.className = 'px-4 py-3';
      const typeBadge = document.createElement('span');
      if (promo.placement === 'exit_intent') {
        typeBadge.className = 'text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300 font-medium';
        typeBadge.textContent = t('promoExitPopup', 'Exit Popup');
      } else if (promo.placement === 'sidebar') {
        typeBadge.className = 'text-xs px-2 py-1 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300 font-medium';
        typeBadge.textContent = t('promoSidebar', 'Sidebar');
      } else if (promo.placement === 'inline') {
        typeBadge.className = 'text-xs px-2 py-1 rounded-full bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300 font-medium';
        typeBadge.textContent = t('promoInline', 'Inline');
      } else {
        typeBadge.className = 'text-xs px-2 py-1 rounded-full bg-sky-100 text-sky-700 dark:bg-sky-900 dark:text-sky-300 font-medium';
        typeBadge.textContent = t('promoBanner', 'Banner');
      }
      tdType.appendChild(typeBadge);
      tr.appendChild(tdType);

      // Image cell
      const tdImg = document.createElement('td');
      tdImg.className = 'px-4 py-3';
      if (promo.image_url) {
        const thumb = document.createElement('img');
        thumb.src = promo.image_url;
        thumb.alt = 'Promo image';
        thumb.className = 'h-10 w-auto rounded object-cover';
        tdImg.appendChild(thumb);
      } else {
        const noImg = document.createElement('span');
        noImg.className = 'text-xs text-gray-400';
        noImg.textContent = '—';
        tdImg.appendChild(noImg);
      }
      tr.appendChild(tdImg);

      // Status cell
      const tdStatus = document.createElement('td');
      tdStatus.className = 'px-4 py-3';
      const statusBadge = document.createElement('span');
      const isActive = Number(promo.is_active) === 1;
      const now = new Date();
      const startsAt = promo.starts_at ? new Date(promo.starts_at) : null;
      const endsAt = promo.ends_at ? new Date(promo.ends_at) : null;
      const isLive = isActive && (!startsAt || startsAt <= now) && (!endsAt || endsAt >= now);
      const isScheduled = isActive && startsAt && startsAt > now;
      const isExpired = isActive && endsAt && endsAt < now;

      if (!isActive) {
        statusBadge.className = 'text-xs px-2 py-1 rounded-full bg-gray-200 text-gray-600 dark:bg-gray-600 dark:text-gray-300';
        statusBadge.textContent = t('promoInactive', 'Inactive');
      } else if (isLive) {
        statusBadge.className = 'text-xs px-2 py-1 rounded-full bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
        statusBadge.textContent = t('promoLive', 'Live');
      } else if (isScheduled) {
        statusBadge.className = 'text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300';
        statusBadge.textContent = t('promoScheduled', 'Scheduled');
      } else if (isExpired) {
        statusBadge.className = 'text-xs px-2 py-1 rounded-full bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300';
        statusBadge.textContent = t('promoExpired', 'Expired');
      }
      tdStatus.appendChild(statusBadge);
      tr.appendChild(tdStatus);

      // Date range cell
      const tdDates = document.createElement('td');
      tdDates.className = 'px-4 py-3 text-sm text-gray-600 dark:text-gray-400';
      const startStr = promo.starts_at ? new Date(promo.starts_at).toLocaleDateString() : t('promoAlways', 'Always');
      const endStr = promo.ends_at ? new Date(promo.ends_at).toLocaleDateString() : t('promoNever', 'Never');
      tdDates.textContent = startStr + ' — ' + endStr;
      tr.appendChild(tdDates);

      // Sort order cell
      const tdSort = document.createElement('td');
      tdSort.className = 'px-4 py-3 text-sm text-center text-gray-600 dark:text-gray-400';
      tdSort.textContent = promo.sort_order || '0';
      tr.appendChild(tdSort);

      // Preview cell (color swatch)
      const tdPreview = document.createElement('td');
      tdPreview.className = 'px-4 py-3';
      const swatch = document.createElement('div');
      swatch.className = 'w-8 h-8 rounded border dark:border-gray-600';
      swatch.style.backgroundColor = promo.bg_color || '#f59e0b';
      swatch.title = 'BG: ' + (promo.bg_color || '#f59e0b');
      tdPreview.appendChild(swatch);
      tr.appendChild(tdPreview);

      // Actions cell
      const tdActions = document.createElement('td');
      tdActions.className = 'px-4 py-3';
      const actionsWrap = document.createElement('div');
      actionsWrap.className = 'flex gap-2';

      const previewBtn = document.createElement('button');
      previewBtn.className = 'text-purple-600 hover:text-purple-800 text-sm font-medium dark:text-purple-400';
      previewBtn.textContent = t('actionPreview', 'Preview');
      previewBtn.addEventListener('click', function() { openPromoPreviewModal(promo); });
      actionsWrap.appendChild(previewBtn);

      const editBtn = document.createElement('button');
      editBtn.className = 'text-blue-600 hover:text-blue-800 text-sm font-medium dark:text-blue-400';
      editBtn.textContent = t('actionEdit', 'Edit');
      editBtn.addEventListener('click', function() { openEditForm(promo); });
      actionsWrap.appendChild(editBtn);

      const toggleBtn = document.createElement('button');
      toggleBtn.className = isActive
        ? 'text-amber-600 hover:text-amber-800 text-sm font-medium dark:text-amber-400'
        : 'text-green-600 hover:text-green-800 text-sm font-medium dark:text-green-400';
      toggleBtn.textContent = isActive ? t('actionDeactivate', 'Deactivate') : t('actionActivate', 'Activate');
      toggleBtn.addEventListener('click', function() { toggleActive(promo); });
      actionsWrap.appendChild(toggleBtn);

      const delBtn = document.createElement('button');
      delBtn.className = 'text-red-600 hover:text-red-800 text-sm font-medium dark:text-red-400';
      delBtn.textContent = t('actionDelete', 'Delete');
      delBtn.addEventListener('click', function() { deletePromotion(promo.id); });
      actionsWrap.appendChild(delBtn);

      tdActions.appendChild(actionsWrap);
      tr.appendChild(tdActions);

      container.appendChild(tr);
    });
  }

  // ─── Toggle form visibility ───────────────────────────────────
  function togglePromotionForm() {
    const form = document.getElementById('promotion-form-panel');
    if (!form) return;
    const isHidden = form.classList.contains('hidden');
    if (isHidden) {
      resetForm();
      form.classList.remove('hidden');
    } else {
      form.classList.add('hidden');
      editingId = null;
    }
  }

  // ─── Reset form fields ────────────────────────────────────────
  function resetForm() {
    editingId = null;
    document.getElementById('promo-placement').value = 'banner';
    document.getElementById('promo-title-en').value = '';
    document.getElementById('promo-title-es').value = '';
    document.getElementById('promo-body-en').value = '';
    document.getElementById('promo-body-es').value = '';
    document.getElementById('promo-cta-text-en').value = 'Book Now';
    document.getElementById('promo-cta-text-es').value = 'Reserve Ahora';
    document.getElementById('promo-cta-url').value = '/book-appointment/';
    document.getElementById('promo-bg-color').value = '#f59e0b';
    document.getElementById('promo-text-color').value = '#000000';
    document.getElementById('promo-badge-en').value = '';
    document.getElementById('promo-badge-es').value = '';
    document.getElementById('promo-active').checked = false;
    document.getElementById('promo-starts').value = '';
    document.getElementById('promo-ends').value = '';
    document.getElementById('promo-sort').value = '0';
    document.getElementById('promo-form-title').textContent = t('promoNewPromo', 'New Promotion');
    document.getElementById('promo-save-btn').textContent = t('promoCreatePromo', 'Create Promotion');
    // Reset exit-intent fields
    document.getElementById('promo-subtitle-en').value = '';
    document.getElementById('promo-subtitle-es').value = '';
    document.getElementById('promo-placeholder-en').value = '';
    document.getElementById('promo-placeholder-es').value = '';
    document.getElementById('promo-success-en').value = '';
    document.getElementById('promo-success-es').value = '';
    document.getElementById('promo-error-en').value = '';
    document.getElementById('promo-error-es').value = '';
    document.getElementById('promo-nospam-en').value = '';
    document.getElementById('promo-nospam-es').value = '';
    document.getElementById('promo-popup-icon').value = '';
    // Reset image
    var imgInput = document.getElementById('promo-image-file');
    if (imgInput) imgInput.value = '';
    var preview = document.getElementById('promo-image-preview');
    if (preview) preview.classList.add('hidden');
    var existing = document.getElementById('promo-existing-image');
    if (existing) existing.classList.add('hidden');
    // Show/hide correct field sections
    toggleExitIntentFields();
  }

  // ─── Open form for editing ────────────────────────────────────
  function openEditForm(promo) {
    editingId = promo.id;
    document.getElementById('promo-placement').value = promo.placement || 'banner';
    document.getElementById('promo-title-en').value = promo.title_en || '';
    document.getElementById('promo-title-es').value = promo.title_es || '';
    document.getElementById('promo-body-en').value = promo.body_en || '';
    document.getElementById('promo-body-es').value = promo.body_es || '';
    document.getElementById('promo-cta-text-en').value = promo.cta_text_en || 'Book Now';
    document.getElementById('promo-cta-text-es').value = promo.cta_text_es || 'Reserve Ahora';
    document.getElementById('promo-cta-url').value = promo.cta_url || '/book-appointment/';
    document.getElementById('promo-bg-color').value = promo.bg_color || '#f59e0b';
    document.getElementById('promo-text-color').value = promo.text_color || '#000000';
    document.getElementById('promo-badge-en').value = promo.badge_text_en || promo.badge_text || '';
    document.getElementById('promo-badge-es').value = promo.badge_text_es || '';
    document.getElementById('promo-active').checked = Number(promo.is_active) === 1;
    document.getElementById('promo-starts').value = promo.starts_at ? promo.starts_at.replace(' ', 'T').slice(0, 16) : '';
    document.getElementById('promo-ends').value = promo.ends_at ? promo.ends_at.replace(' ', 'T').slice(0, 16) : '';
    document.getElementById('promo-sort').value = promo.sort_order || '0';
    // Exit-intent fields
    document.getElementById('promo-subtitle-en').value = promo.subtitle_en || '';
    document.getElementById('promo-subtitle-es').value = promo.subtitle_es || '';
    document.getElementById('promo-placeholder-en').value = promo.placeholder_en || '';
    document.getElementById('promo-placeholder-es').value = promo.placeholder_es || '';
    document.getElementById('promo-success-en').value = promo.success_msg_en || '';
    document.getElementById('promo-success-es').value = promo.success_msg_es || '';
    document.getElementById('promo-error-en').value = promo.error_msg_en || '';
    document.getElementById('promo-error-es').value = promo.error_msg_es || '';
    document.getElementById('promo-nospam-en').value = promo.nospam_en || '';
    document.getElementById('promo-nospam-es').value = promo.nospam_es || '';
    document.getElementById('promo-popup-icon').value = promo.popup_icon || '';
    document.getElementById('promo-form-title').textContent = t('promoEditPromo', 'Edit Promotion');
    document.getElementById('promo-save-btn').textContent = t('promoUpdatePromo', 'Update Promotion');
    // Image
    var imgInput = document.getElementById('promo-image-file');
    if (imgInput) imgInput.value = '';
    var preview = document.getElementById('promo-image-preview');
    if (preview) preview.classList.add('hidden');
    var existing = document.getElementById('promo-existing-image');
    if (existing) {
      if (promo.image_url) {
        existing.classList.remove('hidden');
        var img = existing.querySelector('img');
        if (img) img.src = promo.image_url;
      } else {
        existing.classList.add('hidden');
      }
    }
    // Show/hide correct field sections
    toggleExitIntentFields();

    const form = document.getElementById('promotion-form-panel');
    form.classList.remove('hidden');
    form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // ─── Build FormData from form ─────────────────────────────────
  function buildFormData() {
    const fd = new FormData();
    fd.append('placement', document.getElementById('promo-placement').value);
    fd.append('title_en', document.getElementById('promo-title-en').value.trim());
    fd.append('title_es', document.getElementById('promo-title-es').value.trim());
    fd.append('body_en', document.getElementById('promo-body-en').value.trim());
    fd.append('body_es', document.getElementById('promo-body-es').value.trim());
    fd.append('cta_text_en', document.getElementById('promo-cta-text-en').value.trim() || 'Book Now');
    fd.append('cta_text_es', document.getElementById('promo-cta-text-es').value.trim() || 'Reserve Ahora');
    fd.append('cta_url', document.getElementById('promo-cta-url').value.trim() || '/book-appointment/');
    fd.append('bg_color', document.getElementById('promo-bg-color').value);
    fd.append('text_color', document.getElementById('promo-text-color').value);
    fd.append('badge_text_en', document.getElementById('promo-badge-en').value.trim());
    fd.append('badge_text_es', document.getElementById('promo-badge-es').value.trim());
    fd.append('is_active', document.getElementById('promo-active').checked ? '1' : '0');
    var starts = document.getElementById('promo-starts').value;
    fd.append('starts_at', starts ? starts.replace('T', ' ') + ':00' : '');
    var ends = document.getElementById('promo-ends').value;
    fd.append('ends_at', ends ? ends.replace('T', ' ') + ':00' : '');
    fd.append('sort_order', document.getElementById('promo-sort').value || '0');
    // Exit-intent fields
    fd.append('subtitle_en', document.getElementById('promo-subtitle-en').value.trim());
    fd.append('subtitle_es', document.getElementById('promo-subtitle-es').value.trim());
    fd.append('placeholder_en', document.getElementById('promo-placeholder-en').value.trim());
    fd.append('placeholder_es', document.getElementById('promo-placeholder-es').value.trim());
    fd.append('success_msg_en', document.getElementById('promo-success-en').value.trim());
    fd.append('success_msg_es', document.getElementById('promo-success-es').value.trim());
    fd.append('error_msg_en', document.getElementById('promo-error-en').value.trim());
    fd.append('error_msg_es', document.getElementById('promo-error-es').value.trim());
    fd.append('nospam_en', document.getElementById('promo-nospam-en').value.trim());
    fd.append('nospam_es', document.getElementById('promo-nospam-es').value.trim());
    fd.append('popup_icon', document.getElementById('promo-popup-icon').value.trim());
    // Image file
    var imgInput = document.getElementById('promo-image-file');
    if (imgInput && imgInput.files.length > 0) {
      fd.append('image', imgInput.files[0]);
    }
    return fd;
  }

  // ─── Activation validation ───────────────────────────────────
  function validateActivation(placement, titleEn, bodyEn, subtitleEn) {
    if (!titleEn) {
      return t('promoTitleRequired', 'Title (EN) is required to activate a promotion');
    }
    if (placement === 'exit_intent') {
      if (!subtitleEn) return t('promoSubtitleRequired', 'Subtitle (EN) is required to activate an exit-intent promotion');
    } else {
      if (!bodyEn) return t('promoBodyRequired', 'Body (EN) is required to activate a banner/sidebar/inline promotion');
    }
    return null;
  }

  // ─── Save (create or update) ──────────────────────────────────
  async function savePromotion() {
    const titleEn = document.getElementById('promo-title-en').value.trim();
    if (!titleEn) {
      if (typeof showToast === 'function') showToast(t('promoTitleRequired', 'Title (EN) is required'), true);
      return;
    }

    // Validate required fields if activating
    var isActiveChecked = document.getElementById('promo-active').checked;
    if (isActiveChecked) {
      var placement = document.getElementById('promo-placement').value;
      var bodyEn = document.getElementById('promo-body-en').value.trim();
      var subtitleEn = document.getElementById('promo-subtitle-en').value.trim();
      var validationError = validateActivation(placement, titleEn, bodyEn, subtitleEn);
      if (validationError) {
        if (typeof showToast === 'function') showToast(validationError, true);
        return;
      }
    }

    const fd = buildFormData();

    if (editingId) {
      fd.append('_method', 'PUT');
      fd.append('id', String(editingId));
    }

    try {
      const res = await fetch(API, {
        method: 'POST',
        headers: { 'X-CSRF-Token': getCsrf() },
        credentials: 'include',
        body: fd,
      });
      const json = await res.json();
      if (json.success) {
        if (typeof showToast === 'function') showToast(editingId ? t('promoUpdated', 'Promotion updated') : t('promoCreated', 'Promotion created'));
        document.getElementById('promotion-form-panel').classList.add('hidden');
        editingId = null;
        loadPromotions();
      } else {
        if (typeof showToast === 'function') showToast(json.error || t('promoSaveFail', 'Save failed'), true);
      }
    } catch (err) {
      console.error('savePromotion error:', err);
      if (typeof showToast === 'function') showToast(t('promoNetworkError', 'Network error'), true);
    }
  }

  // ─── Toggle active status ─────────────────────────────────────
  async function toggleActive(promo) {
    var activating = Number(promo.is_active) !== 1;
    if (activating) {
      var validationError = validateActivation(
        promo.placement || 'banner',
        promo.title_en || '',
        promo.body_en || '',
        promo.subtitle_en || ''
      );
      if (validationError) {
        if (typeof showToast === 'function') showToast(validationError, true);
        return;
      }
    }

    const fd = new FormData();
    fd.append('_method', 'PUT');
    fd.append('id', String(promo.id));
    fd.append('placement', promo.placement || 'banner');
    fd.append('title_en', promo.title_en || '');
    fd.append('title_es', promo.title_es || '');
    fd.append('body_en', promo.body_en || '');
    fd.append('body_es', promo.body_es || '');
    fd.append('subtitle_en', promo.subtitle_en || '');
    fd.append('subtitle_es', promo.subtitle_es || '');
    fd.append('cta_text_en', promo.cta_text_en || 'Book Now');
    fd.append('cta_text_es', promo.cta_text_es || 'Reserve Ahora');
    fd.append('cta_url', promo.cta_url || '/book-appointment/');
    fd.append('placeholder_en', promo.placeholder_en || '');
    fd.append('placeholder_es', promo.placeholder_es || '');
    fd.append('success_msg_en', promo.success_msg_en || '');
    fd.append('success_msg_es', promo.success_msg_es || '');
    fd.append('error_msg_en', promo.error_msg_en || '');
    fd.append('error_msg_es', promo.error_msg_es || '');
    fd.append('nospam_en', promo.nospam_en || '');
    fd.append('nospam_es', promo.nospam_es || '');
    fd.append('popup_icon', promo.popup_icon || '');
    fd.append('bg_color', promo.bg_color || '#f59e0b');
    fd.append('text_color', promo.text_color || '#000000');
    fd.append('badge_text_en', promo.badge_text_en || promo.badge_text || '');
    fd.append('badge_text_es', promo.badge_text_es || '');
    fd.append('is_active', Number(promo.is_active) === 1 ? '0' : '1');
    fd.append('starts_at', promo.starts_at || '');
    fd.append('ends_at', promo.ends_at || '');
    fd.append('sort_order', String(promo.sort_order || 0));

    try {
      const res = await fetch(API, {
        method: 'POST',
        headers: { 'X-CSRF-Token': getCsrf() },
        credentials: 'include',
        body: fd,
      });
      const json = await res.json();
      if (json.success) {
        if (typeof showToast === 'function') showToast(Number(promo.is_active) === 1 ? t('promoDeactivated', 'Promotion deactivated') : t('promoActivated', 'Promotion activated'));
        loadPromotions();
      }
    } catch (err) {
      console.error('toggleActive error:', err);
    }
  }

  // ─── Delete promotion ─────────────────────────────────────────
  async function deletePromotion(id) {
    if (!confirm(t('promoDeleteConfirm', 'Delete this promotion? This cannot be undone.'))) return;

    try {
      const res = await fetch(API + '?id=' + id, {
        method: 'DELETE',
        headers: { 'X-CSRF-Token': getCsrf() },
        credentials: 'include',
      });
      const json = await res.json();
      if (json.success) {
        if (typeof showToast === 'function') showToast(t('promoDeleted', 'Promotion deleted'));
        loadPromotions();
      }
    } catch (err) {
      console.error('deletePromotion error:', err);
    }
  }

  // ─── Remove promo image ───────────────────────────────────────
  function removePromoImage() {
    var existing = document.getElementById('promo-existing-image');
    if (existing) existing.classList.add('hidden');
    // Mark for removal on next save
    var removeFlag = document.getElementById('promo-remove-image-flag');
    if (!removeFlag) {
      removeFlag = document.createElement('input');
      removeFlag.type = 'hidden';
      removeFlag.id = 'promo-remove-image-flag';
      document.getElementById('promotion-form-panel').appendChild(removeFlag);
    }
    removeFlag.value = '1';
  }

  // ─── Render preview into a container ──────────────────────────
  function renderPromoPreview(container, data, lang) {
    lang = lang || 'en';
    container.textContent = '';

    var placement = data.placement || 'banner';
    var bgColor = data.bg_color || '#f59e0b';
    var textColor = data.text_color || '#000000';
    var title = (lang === 'es' ? (data.title_es || data.title_en) : data.title_en) || 'Your Promotion Title';
    var body = (lang === 'es' ? (data.body_es || data.body_en) : data.body_en) || '';
    var subtitle = (lang === 'es' ? (data.subtitle_es || data.subtitle_en) : data.subtitle_en) || '';
    var badge = (lang === 'es' ? (data.badge_text_es || data.badge_text_en) : data.badge_text_en) || '';
    var ctaText = (lang === 'es' ? (data.cta_text_es || data.cta_text_en) : data.cta_text_en) || 'Book Now';
    var icon = data.popup_icon || '';
    var imageUrl = data.image_url || '';

    // Placement label
    var label = document.createElement('div');
    label.className = 'text-xs text-gray-400 dark:text-gray-500 uppercase tracking-wide mb-2 px-1';
    var placementNames = { banner: 'Banner Preview', exit_intent: 'Exit-Intent Popup Preview', sidebar: 'Sidebar Preview', inline: 'Inline Preview' };
    label.textContent = placementNames[placement] || 'Banner Preview';
    container.appendChild(label);

    if (placement === 'exit_intent') {
      // Exit-intent: centered card on dark overlay
      var overlay = document.createElement('div');
      overlay.className = 'rounded-xl p-6 flex items-center justify-center min-h-[280px]';
      overlay.style.backgroundColor = 'rgba(0,0,0,0.65)';

      var card = document.createElement('div');
      card.className = 'rounded-xl p-6 text-center max-w-sm w-full shadow-2xl relative';
      card.style.backgroundColor = bgColor;
      card.style.color = textColor;

      // Close X
      var closeX = document.createElement('span');
      closeX.className = 'absolute top-3 right-4 text-lg opacity-50 cursor-default';
      closeX.textContent = '\u2715';
      card.appendChild(closeX);

      if (icon) {
        var iconEl = document.createElement('div');
        iconEl.className = 'text-3xl mb-2';
        iconEl.textContent = icon;
        card.appendChild(iconEl);
      }
      var h3 = document.createElement('div');
      h3.className = 'font-bold text-xl mb-1';
      h3.textContent = title;
      card.appendChild(h3);
      if (subtitle) {
        var sub = document.createElement('div');
        sub.className = 'text-sm opacity-80 mb-3';
        sub.textContent = subtitle;
        card.appendChild(sub);
      }
      if (body) {
        var bodyP = document.createElement('div');
        bodyP.className = 'text-sm opacity-70 mb-4';
        bodyP.textContent = body.length > 120 ? body.substring(0, 120) + '...' : body;
        card.appendChild(bodyP);
      }
      // Email input (visual only)
      var emailRow = document.createElement('div');
      emailRow.className = 'flex gap-2 mb-3';
      var emailInput = document.createElement('input');
      emailInput.type = 'email';
      emailInput.disabled = true;
      emailInput.placeholder = data.placeholder_en || 'your@email.com';
      emailInput.className = 'flex-1 px-3 py-2 rounded text-sm text-gray-800 bg-white/90 border-0';
      emailRow.appendChild(emailInput);
      var ctaBtn = document.createElement('button');
      ctaBtn.className = 'px-4 py-2 rounded font-bold text-sm whitespace-nowrap';
      ctaBtn.style.backgroundColor = textColor;
      ctaBtn.style.color = bgColor;
      ctaBtn.textContent = ctaText;
      emailRow.appendChild(ctaBtn);
      card.appendChild(emailRow);
      // No spam line
      var nospam = document.createElement('div');
      nospam.className = 'text-xs opacity-50';
      nospam.textContent = data.nospam_en || 'No spam. Unsubscribe anytime.';
      card.appendChild(nospam);

      overlay.appendChild(card);
      container.appendChild(overlay);

    } else if (placement === 'sidebar') {
      // Sidebar: compact card
      var wrap = document.createElement('div');
      wrap.className = 'max-w-[260px] rounded-lg overflow-hidden shadow';
      wrap.style.backgroundColor = bgColor;
      wrap.style.color = textColor;

      if (imageUrl) {
        var img = document.createElement('img');
        img.src = imageUrl;
        img.alt = '';
        img.className = 'w-full h-28 object-cover';
        wrap.appendChild(img);
      }
      var content = document.createElement('div');
      content.className = 'p-3';
      if (badge) {
        var badgeEl = document.createElement('span');
        badgeEl.className = 'inline-block px-2 py-0.5 rounded-full text-xs font-bold mb-1 border';
        badgeEl.style.borderColor = textColor;
        badgeEl.textContent = badge;
        content.appendChild(badgeEl);
      }
      var titleEl = document.createElement('div');
      titleEl.className = 'font-semibold text-sm';
      titleEl.textContent = title;
      content.appendChild(titleEl);
      if (body) {
        var bodyEl = document.createElement('div');
        bodyEl.className = 'text-xs opacity-80 mt-1';
        bodyEl.textContent = body.length > 80 ? body.substring(0, 80) + '...' : body;
        content.appendChild(bodyEl);
      }
      var cta = document.createElement('div');
      cta.className = 'mt-2 underline font-bold text-xs';
      cta.textContent = ctaText + ' \u2192';
      content.appendChild(cta);
      wrap.appendChild(content);
      container.appendChild(wrap);

    } else {
      // Banner / Inline
      var bar = document.createElement('div');
      bar.className = 'px-4 py-3 flex items-center justify-between gap-3 flex-wrap' + (placement === 'banner' ? '' : ' rounded-lg');
      bar.style.backgroundColor = bgColor;
      bar.style.color = textColor;

      var left = document.createElement('div');
      left.className = 'flex items-center gap-3 flex-wrap';
      if (badge) {
        var badgeEl2 = document.createElement('span');
        badgeEl2.className = 'inline-block px-2.5 py-0.5 rounded-full text-xs font-bold border';
        badgeEl2.style.borderColor = textColor;
        badgeEl2.textContent = badge;
        left.appendChild(badgeEl2);
      }
      var titleSpan = document.createElement('span');
      titleSpan.className = 'font-semibold';
      titleSpan.textContent = title;
      left.appendChild(titleSpan);
      if (body) {
        var sep = document.createElement('span');
        sep.className = 'opacity-60 hidden sm:inline';
        sep.textContent = ' — ';
        left.appendChild(sep);
        var bodySnip = document.createElement('span');
        bodySnip.className = 'text-sm opacity-80 hidden sm:inline';
        bodySnip.textContent = body.length > 60 ? body.substring(0, 60) + '...' : body;
        left.appendChild(bodySnip);
      }
      bar.appendChild(left);

      var right = document.createElement('div');
      right.className = 'flex items-center gap-3';
      var ctaBtn2 = document.createElement('span');
      ctaBtn2.className = 'px-3 py-1 rounded font-bold text-sm whitespace-nowrap';
      ctaBtn2.style.backgroundColor = textColor;
      ctaBtn2.style.color = bgColor;
      ctaBtn2.textContent = ctaText;
      right.appendChild(ctaBtn2);
      var dismissX = document.createElement('span');
      dismissX.className = 'opacity-50 cursor-default text-lg';
      dismissX.textContent = '\u2715';
      right.appendChild(dismissX);
      bar.appendChild(right);

      container.appendChild(bar);
    }
  }

  // ─── Live preview (form) ────────────────────────────────────
  function updatePreview() {
    var preview = document.getElementById('promo-live-preview');
    if (!preview) return;

    var data = {
      placement: document.getElementById('promo-placement').value,
      bg_color: document.getElementById('promo-bg-color').value,
      text_color: document.getElementById('promo-text-color').value,
      title_en: document.getElementById('promo-title-en').value || 'Your Promotion Title',
      body_en: document.getElementById('promo-body-en').value,
      badge_text_en: document.getElementById('promo-badge-en').value,
      cta_text_en: document.getElementById('promo-cta-text-en').value || 'Book Now',
      subtitle_en: document.getElementById('promo-subtitle-en').value,
      popup_icon: document.getElementById('promo-popup-icon').value,
      placeholder_en: document.getElementById('promo-placeholder-en').value,
      nospam_en: document.getElementById('promo-nospam-en').value
    };

    renderPromoPreview(preview, data, 'en');
  }

  // ─── Preview modal ──────────────────────────────────────────
  var previewModalLang = 'en';

  function openPromoPreviewModal(promo) {
    previewModalLang = 'en';
    var modal = document.getElementById('promo-preview-modal');
    if (!modal) return;
    var body = document.getElementById('promo-preview-modal-body');
    body.textContent = '';

    var langBtn = document.getElementById('promo-preview-lang-toggle');
    langBtn.textContent = 'EN / ES';

    // Render EN preview
    renderPromoPreview(body, promo, 'en');

    // Lang toggle
    langBtn.onclick = function() {
      previewModalLang = previewModalLang === 'en' ? 'es' : 'en';
      langBtn.textContent = previewModalLang === 'en' ? 'EN / ES' : 'ES / EN';
      body.textContent = '';
      renderPromoPreview(body, promo, previewModalLang);
    };

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  function closePromoPreviewModal() {
    var modal = document.getElementById('promo-preview-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  }

  // Override buildFormData to include remove_image flag
  var _origBuildFormData = buildFormData;
  function buildFormDataWithRemove() {
    var fd = _origBuildFormData();
    var removeFlag = document.getElementById('promo-remove-image-flag');
    if (removeFlag && removeFlag.value === '1') {
      fd.append('remove_image', '1');
    }
    return fd;
  }
  // Patch
  buildFormData = buildFormDataWithRemove;

  // ─── Image file input preview ─────────────────────────────────
  document.addEventListener('DOMContentLoaded', function() {
    var imgInput = document.getElementById('promo-image-file');
    if (imgInput) {
      imgInput.addEventListener('change', function() {
        var preview = document.getElementById('promo-image-preview');
        if (!preview) return;
        if (this.files && this.files[0]) {
          var reader = new FileReader();
          reader.onload = function(e) {
            var img = preview.querySelector('img');
            if (img) img.src = e.target.result;
            preview.classList.remove('hidden');
          };
          reader.readAsDataURL(this.files[0]);
          // Clear remove flag
          var removeFlag = document.getElementById('promo-remove-image-flag');
          if (removeFlag) removeFlag.value = '';
        } else {
          preview.classList.add('hidden');
        }
      });
    }
  });

  // ─── Expose to global scope ───────────────────────────────────
  window.loadPromotions = loadPromotions;
  window.togglePromotionForm = togglePromotionForm;
  window.savePromotion = savePromotion;
  window.updatePromoPreview = updatePreview;
  window.removePromoImage = removePromoImage;
  window.toggleExitIntentFields = toggleExitIntentFields;
  window.openPromoPreviewModal = openPromoPreviewModal;
  window.closePromoPreviewModal = closePromoPreviewModal;
})();
