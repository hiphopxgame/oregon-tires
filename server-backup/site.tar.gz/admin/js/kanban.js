/**
 * Oregon Tires — Admin Kanban Board Module
 * Drag-and-drop kanban view for repair order workflow management.
 *
 * Depends on: api(), showToast(), viewRoDetail() from admin/index.html + repair-orders.js
 */

(function() {
'use strict';

// ─── Column definitions ─────────────────────────────────────────────────────
var COLUMNS = [
  { key: 'intake',           label: 'Intake',      color: '#3b82f6' },
  { key: 'check_in',         label: 'Check In',    color: '#06b6d4' },
  { key: 'diagnosis',        label: 'Diagnosis',   color: '#8b5cf6' },
  { key: 'estimate_pending', label: 'Estimate',    color: '#f59e0b' },
  { key: 'pending_approval', label: 'Approval',    color: '#f59e0b' },
  { key: 'approved',         label: 'Approved',    color: '#22c55e' },
  { key: 'in_progress',      label: 'In Progress', color: '#16a34a' },
  { key: 'on_hold',          label: 'On Hold',     color: '#991b1b' },
  { key: 'waiting_parts',    label: 'Parts',       color: '#f97316' },
  { key: 'ready',            label: 'Ready',       color: '#14b8a6' },
  { key: 'completed',        label: 'Done',        color: '#6b7280' },
  { key: 'invoiced',         label: 'Invoiced',    color: '#0d9488' }
];

var kanbanActive = false;

function t(key, fallback) {
  return (typeof adminT !== 'undefined' && adminT[currentLang] && adminT[currentLang][key]) || fallback;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function isDark() {
  return document.documentElement.classList.contains('dark');
}

function timeAgo(dateStr) {
  if (!dateStr) return '';
  var now = Date.now();
  var then = new Date(dateStr).getTime();
  var diff = now - then;
  if (diff < 0) diff = 0;

  var seconds = Math.floor(diff / 1000);
  var minutes = Math.floor(seconds / 60);
  var hours   = Math.floor(minutes / 60);
  var days    = Math.floor(hours / 24);

  if (days > 0)    return days + t('kanbanTimeDayAgo', 'd ago');
  if (hours > 0)   return hours + t('kanbanTimeHrAgo', 'h ago');
  if (minutes > 0) return minutes + t('kanbanTimeMinAgo', 'm ago');
  return t('kanbanTimeJustNow', 'just now');
}

function abbreviateVehicle(year, make, model) {
  var parts = [year, make, model].filter(Boolean);
  if (parts.length === 0) return '-';
  // Abbreviate long model names
  var str = parts.join(' ');
  if (str.length > 22) {
    str = str.substring(0, 20) + '...';
  }
  return str;
}

// ─── Next-action logic ───────────────────────────────────────────────────────
function getNextAction(ro) {
  var s = ro.status || 'intake';
  var hasInspection = (ro.inspection_count || 0) > 0;
  var hasEstimate = (ro.estimate_count || 0) > 0;
  var dark = isDark();

  if (s === 'intake') return { label: 'Check In', bg: dark ? '#164e63' : '#cffafe', color: dark ? '#67e8f9' : '#0e7490' };
  if (s === 'check_in') return { label: 'Start Diag', bg: dark ? '#3b0764' : '#ede9fe', color: dark ? '#c4b5fd' : '#6d28d9' };
  if (s === 'diagnosis' && !hasEstimate) return { label: 'Needs Est.', bg: dark ? '#451a03' : '#fef3c7', color: dark ? '#fcd34d' : '#92400e' };
  if (s === 'estimate_pending') return { label: 'Send Est.', bg: dark ? '#1e3a5f' : '#dbeafe', color: dark ? '#93c5fd' : '#1d4ed8' };
  if (s === 'pending_approval') return { label: 'Awaiting', bg: dark ? '#431407' : '#ffedd5', color: dark ? '#fdba74' : '#c2410c' };
  if (s === 'approved') return { label: 'Start Work', bg: dark ? '#052e16' : '#dcfce7', color: dark ? '#86efac' : '#166534' };
  if (s === 'ready') return { label: 'Complete', bg: dark ? '#022c22' : '#d1fae5', color: dark ? '#6ee7b7' : '#065f46' };
  if (s === 'completed') return { label: 'Invoice', bg: dark ? '#042f2e' : '#ccfbf1', color: dark ? '#5eead4' : '#0f766e' };
  return null;
}

// ─── Next-status mapping for quick advance ──────────────────────────────────
function getNextStatus(ro) {
  var s = ro.status || 'intake';
  var hasEstimate = (ro.estimate_count || 0) > 0;

  var map = {
    'intake': 'check_in',
    'check_in': 'diagnosis',
    'estimate_pending': 'pending_approval',
    'pending_approval': 'approved',
    'approved': 'in_progress',
    'in_progress': 'ready',
    'ready': 'completed',
    'completed': 'invoiced'
  };

  // diagnosis only advances if it has an estimate
  if (s === 'diagnosis' && hasEstimate) return 'estimate_pending';
  if (s === 'diagnosis') return null; // can't advance without estimate

  return map[s] || null;
}

// ─── Build a kanban card ─────────────────────────────────────────────────────

function createCard(ro) {
  var dark = isDark();

  var card = document.createElement('div');
  card.setAttribute('draggable', 'true');
  card.setAttribute('data-ro-id', String(ro.id));
  card.setAttribute('data-ro-status', ro.status || 'intake');
  card.style.cssText =
    'background:' + (dark ? '#374151' : '#ffffff') + ';' +
    'border-radius:6px;' +
    'padding:10px;' +
    'margin-bottom:8px;' +
    'cursor:grab;' +
    'box-shadow:0 1px 3px rgba(0,0,0,0.1);' +
    'transition:box-shadow 0.15s, transform 0.15s;' +
    'border:1px solid ' + (dark ? '#4b5563' : '#e5e7eb') + ';';

  // Click → detail (also handled by overlay "Open" button)
  card.addEventListener('click', function() {
    if (typeof viewRoDetail === 'function') {
      viewRoDetail(ro.id);
    }
  });

  // Drag events
  card.addEventListener('dragstart', function(e) {
    e.dataTransfer.setData('text/plain', String(ro.id));
    e.dataTransfer.effectAllowed = 'move';
    card.style.opacity = '0.5';
    card.style.cursor = 'grabbing';
  });
  card.addEventListener('dragend', function() {
    card.style.opacity = '1';
    card.style.cursor = 'grab';
  });

  // RO number
  var roNum = document.createElement('div');
  roNum.style.cssText =
    'font-weight:700;' +
    'font-size:13px;' +
    'color:' + (dark ? '#4ade80' : '#15803d') + ';' +
    'margin-bottom:4px;';
  roNum.textContent = ro.ro_number || 'RO-???';
  card.appendChild(roNum);

  // Customer name
  var custName = ((ro.first_name || '') + ' ' + (ro.last_name || '')).trim();
  if (custName) {
    var custEl = document.createElement('div');
    custEl.style.cssText =
      'font-size:12px;' +
      'color:' + (dark ? '#d1d5db' : '#374151') + ';' +
      'margin-bottom:2px;' +
      'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
    custEl.textContent = custName;
    card.appendChild(custEl);
  }

  // Vehicle
  var vehicle = abbreviateVehicle(ro.vehicle_year, ro.vehicle_make, ro.vehicle_model);
  var vehEl = document.createElement('div');
  vehEl.style.cssText =
    'font-size:11px;' +
    'color:' + (dark ? '#9ca3af' : '#6b7280') + ';' +
    'margin-bottom:4px;' +
    'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
  vehEl.textContent = vehicle;
  card.appendChild(vehEl);

  // Active labor indicator
  if (ro.active_labor_count > 0) {
    var laborInd = document.createElement('div');
    laborInd.style.cssText = 'display:flex;align-items:center;gap:4px;margin-bottom:3px;';
    var pulseDot = document.createElement('span');
    pulseDot.style.cssText = 'width:6px;height:6px;border-radius:50%;background:#22c55e;display:inline-block;';
    pulseDot.className = 'animate-pulse';
    laborInd.appendChild(pulseDot);
    var laborText = document.createElement('span');
    laborText.style.cssText = 'font-size:10px;font-weight:600;color:' + (dark ? '#4ade80' : '#16a34a') + ';';
    laborText.textContent = ro.active_labor_count + ' ' + (ro.active_labor_count === 1 ? 'tech working' : 'techs working');
    laborInd.appendChild(laborText);
    card.appendChild(laborInd);
  }

  // Bottom row: time + next-action badge
  var bottomRow = document.createElement('div');
  bottomRow.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-top:2px;';

  var timeEl = document.createElement('div');
  timeEl.style.cssText =
    'font-size:10px;' +
    'color:' + (dark ? '#6b7280' : '#9ca3af') + ';';
  timeEl.textContent = timeAgo(ro.updated_at);
  bottomRow.appendChild(timeEl);

  // Next-action indicator
  var nextAction = getNextAction(ro);
  if (nextAction) {
    var actionBadge = document.createElement('span');
    actionBadge.style.cssText =
      'font-size:9px;font-weight:600;padding:1px 5px;border-radius:3px;white-space:nowrap;' +
      'background:' + nextAction.bg + ';color:' + nextAction.color + ';';
    actionBadge.textContent = nextAction.label;
    bottomRow.appendChild(actionBadge);
  }
  card.appendChild(bottomRow);

  // ─── Hover quick-action overlay ───────────────────────────────────────────
  var overlay = document.createElement('div');
  overlay.style.cssText =
    'position:absolute;bottom:0;left:0;right:0;' +
    'display:none;' +
    'justify-content:center;' +
    'align-items:center;' +
    'gap:6px;' +
    'padding:6px;' +
    'background:' + (dark ? 'rgba(17,24,39,0.88)' : 'rgba(255,255,255,0.88)') + ';' +
    'backdrop-filter:blur(2px);' +
    'border-radius:0 0 6px 6px;' +
    'border-top:1px solid ' + (dark ? '#374151' : '#e5e7eb') + ';';

  // "Open" button
  var openBtn = document.createElement('button');
  openBtn.style.cssText =
    'font-size:11px;font-weight:600;padding:3px 10px;border-radius:4px;border:none;cursor:pointer;' +
    'background:' + (dark ? '#374151' : '#e5e7eb') + ';' +
    'color:' + (dark ? '#d1d5db' : '#374151') + ';' +
    'transition:background 0.15s;';
  openBtn.textContent = t('kanbanOpen', 'Open');
  openBtn.addEventListener('mouseenter', function() {
    openBtn.style.background = dark ? '#4b5563' : '#d1d5db';
  });
  openBtn.addEventListener('mouseleave', function() {
    openBtn.style.background = dark ? '#374151' : '#e5e7eb';
  });
  openBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    if (typeof viewRoDetail === 'function') {
      viewRoDetail(ro.id);
    }
  });
  overlay.appendChild(openBtn);

  // "Next" button (only if there's a valid next status)
  var nextStatus = getNextStatus(ro);
  if (nextStatus && nextAction) {
    var nextBtn = document.createElement('button');
    nextBtn.style.cssText =
      'font-size:11px;font-weight:600;padding:3px 10px;border-radius:4px;border:none;cursor:pointer;' +
      'background:' + nextAction.color + ';' +
      'color:#ffffff;' +
      'transition:opacity 0.15s;';
    var friendlyNext = nextStatus.replace(/_/g, ' ');
    friendlyNext = friendlyNext.charAt(0).toUpperCase() + friendlyNext.slice(1);
    nextBtn.textContent = t('kanbanNext', 'Next') + ' \u2192';
    nextBtn.title = friendlyNext;
    nextBtn.addEventListener('mouseenter', function() {
      nextBtn.style.opacity = '0.85';
    });
    nextBtn.addEventListener('mouseleave', function() {
      nextBtn.style.opacity = '1';
    });
    nextBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      handleStatusDrop(ro.id, nextStatus);
    });
    overlay.appendChild(nextBtn);
  }

  // Card needs position:relative for the overlay
  card.style.position = 'relative';
  card.style.overflow = 'hidden';
  card.appendChild(overlay);

  // Show/hide overlay on hover
  card.addEventListener('mouseenter', function() {
    overlay.style.display = 'flex';
    card.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
    card.style.transform = 'translateY(-1px)';
  });
  card.addEventListener('mouseleave', function() {
    overlay.style.display = 'none';
    card.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
    card.style.transform = 'translateY(0)';
  });

  return card;
}

// ─── Build a kanban column ───────────────────────────────────────────────────

function createColumn(colDef, cards) {
  var dark = isDark();

  var col = document.createElement('div');
  col.setAttribute('data-status', colDef.key);
  col.style.cssText =
    'min-width:180px;' +
    'max-width:220px;' +
    'flex:1 0 180px;' +
    'background:' + (dark ? '#1f2937' : '#f9fafb') + ';' +
    'border-radius:8px;' +
    'padding:8px;' +
    'display:flex;' +
    'flex-direction:column;' +
    'border-top:3px solid ' + colDef.color + ';' +
    'transition:border-color 0.2s, box-shadow 0.2s;';

  // Header
  var header = document.createElement('div');
  header.style.cssText =
    'display:flex;' +
    'align-items:center;' +
    'justify-content:space-between;' +
    'margin-bottom:8px;' +
    'padding:4px 2px;';

  var label = document.createElement('span');
  label.style.cssText =
    'font-size:12px;' +
    'font-weight:700;' +
    'color:' + (dark ? '#e5e7eb' : '#374151') + ';' +
    'text-transform:uppercase;' +
    'letter-spacing:0.5px;';
  var labelKeys = {
    intake: 'roStatusIntake',
    check_in: 'roStatusCheckIn',
    diagnosis: 'roStatusDiagnosis',
    estimate_pending: 'roTimelineEst',
    pending_approval: 'roTimelineApproval',
    approved: 'roStatusApproved',
    in_progress: 'roStatusInProgress',
    on_hold: 'roStatusOnHold',
    waiting_parts: 'roTimelineParts',
    ready: 'roStatusReady',
    completed: 'roTimelineDone',
    invoiced: 'roStatusInvoiced'
  };
  label.textContent = t(labelKeys[colDef.key], colDef.label);

  var badge = document.createElement('span');
  badge.style.cssText =
    'font-size:11px;' +
    'font-weight:700;' +
    'color:' + (dark ? '#d1d5db' : '#ffffff') + ';' +
    'background:' + colDef.color + ';' +
    'border-radius:9999px;' +
    'min-width:20px;' +
    'height:20px;' +
    'display:inline-flex;' +
    'align-items:center;' +
    'justify-content:center;' +
    'padding:0 6px;';
  badge.textContent = String(cards.length);

  header.appendChild(label);
  header.appendChild(badge);
  col.appendChild(header);

  // Card list (scrollable)
  var cardList = document.createElement('div');
  cardList.setAttribute('data-drop-zone', colDef.key);
  cardList.style.cssText =
    'flex:1;' +
    'overflow-y:auto;' +
    'min-height:60px;' +
    'padding:2px;';

  cards.forEach(function(ro) {
    cardList.appendChild(createCard(ro));
  });

  // Empty state
  if (cards.length === 0) {
    var empty = document.createElement('div');
    empty.style.cssText =
      'text-align:center;' +
      'padding:16px 8px;' +
      'font-size:11px;' +
      'color:' + (dark ? '#4b5563' : '#d1d5db') + ';';
    empty.textContent = t('kanbanNoOrders', 'No orders');
    cardList.appendChild(empty);
  }

  col.appendChild(cardList);

  // ─── Drop zone handlers ───────────────────────────────────────────────────

  col.addEventListener('dragover', function(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    col.style.boxShadow = '0 0 0 2px ' + colDef.color;
    col.style.background = dark ? '#283548' : '#f0fdf4';
  });

  col.addEventListener('dragleave', function(e) {
    // Only fire when actually leaving the column (not entering a child)
    if (col.contains(e.relatedTarget)) return;
    col.style.boxShadow = 'none';
    col.style.background = dark ? '#1f2937' : '#f9fafb';
  });

  col.addEventListener('drop', function(e) {
    e.preventDefault();
    col.style.boxShadow = 'none';
    col.style.background = dark ? '#1f2937' : '#f9fafb';

    var roId = e.dataTransfer.getData('text/plain');
    if (!roId) return;

    var newStatus = colDef.key;

    // Find the card's current status
    var draggedCard = document.querySelector('[data-ro-id="' + roId + '"]');
    var oldStatus = draggedCard ? draggedCard.getAttribute('data-ro-status') : null;

    if (oldStatus === newStatus) return;

    // Update via API
    handleStatusDrop(parseInt(roId, 10), newStatus);
  });

  return col;
}

// ─── Handle drag-and-drop status change ──────────────────────────────────────

async function handleStatusDrop(roId, newStatus) {
  try {
    await api('repair-orders.php', {
      method: 'PUT',
      body: { id: roId, status: newStatus }
    });
    var friendlyStatus = newStatus.replace(/_/g, ' ');
    showToast(t('roMovedTo', 'Moved to') + ' ' + friendlyStatus.charAt(0).toUpperCase() + friendlyStatus.slice(1));
    // Reload the kanban board
    loadKanban();
    // Also refresh the table data in the background so switching views stays in sync
    if (typeof loadRepairOrders === 'function') {
      loadRepairOrders();
    }
  } catch (err) {
    showToast(t('kanbanFailedUpdate', 'Failed to update status') + ': ' + (err.message || 'Unknown error'), true);
  }
}

// ─── Render the kanban board ─────────────────────────────────────────────────

function renderKanban(orders) {
  var container = document.getElementById('ro-kanban-view');
  if (!container) return;
  container.textContent = '';

  var dark = isDark();

  // Board wrapper
  var board = document.createElement('div');
  board.style.cssText =
    'display:flex;' +
    'gap:12px;' +
    'overflow-x:auto;' +
    'padding:16px 0;' +
    'min-height:400px;' +
    '-webkit-overflow-scrolling:touch;';

  // Group orders by status
  var buckets = {};
  COLUMNS.forEach(function(col) {
    buckets[col.key] = [];
  });
  orders.forEach(function(ro) {
    var status = ro.status || 'intake';
    if (buckets[status]) {
      buckets[status].push(ro);
    }
    // Skip cancelled — they don't have a column
  });

  // Build columns
  COLUMNS.forEach(function(colDef) {
    board.appendChild(createColumn(colDef, buckets[colDef.key]));
  });

  container.appendChild(board);
}

// ─── loadKanban (exposed globally) ───────────────────────────────────────────

window.loadKanban = async function() {
  var container = document.getElementById('ro-kanban-view');
  if (!container) return;

  // Show loading state
  container.textContent = '';
  var loadingMsg = document.createElement('div');
  loadingMsg.style.cssText =
    'text-align:center;' +
    'padding:40px;' +
    'color:' + (isDark() ? '#9ca3af' : '#6b7280') + ';' +
    'font-size:14px;';
  loadingMsg.textContent = t('kanbanLoading', 'Loading kanban board...');
  container.appendChild(loadingMsg);

  try {
    // Fetch all non-cancelled ROs (up to 100)
    var params = new URLSearchParams({
      limit: 100,
      offset: 0,
      sort_by: 'updated_at',
      sort_order: 'DESC'
    });

    var json = await api('repair-orders.php?' + params.toString());
    var allOrders = json.data || [];

    // Filter out cancelled orders
    var activeOrders = allOrders.filter(function(ro) {
      return ro.status !== 'cancelled';
    });

    renderKanban(activeOrders);
  } catch (err) {
    container.textContent = '';
    var errMsg = document.createElement('div');
    errMsg.style.cssText =
      'text-align:center;' +
      'padding:40px;' +
      'color:#ef4444;' +
      'font-size:14px;';
    errMsg.textContent = t('kanbanFailedLoad', 'Failed to load kanban') + ': ' + (err.message || 'Unknown error');
    container.appendChild(errMsg);
    console.error('loadKanban error:', err);
  }
};

// ─── toggleKanbanView (exposed globally) ─────────────────────────────────────

window.toggleKanbanView = function() {
  var tableView  = document.getElementById('ro-table-view');
  var kanbanView = document.getElementById('ro-kanban-view');
  var toggleBtn  = document.getElementById('ro-view-toggle');

  if (!tableView || !kanbanView) return;

  kanbanActive = !kanbanActive;

  if (kanbanActive) {
    // Show kanban, hide table
    tableView.style.display = 'none';
    kanbanView.style.display = 'block';
    if (toggleBtn) {
      toggleBtn.textContent = '';
      var tableIcon = document.createTextNode(t('kanbanTableView', 'Table View'));
      toggleBtn.appendChild(tableIcon);
    }
    loadKanban();
  } else {
    // Show table, hide kanban
    tableView.style.display = '';
    kanbanView.style.display = 'none';
    if (toggleBtn) {
      toggleBtn.textContent = '';
      var kanbanIcon = document.createTextNode(t('kanbanView', 'Kanban View'));
      toggleBtn.appendChild(kanbanIcon);
    }
  }
};

// ─── Inject the toggle button and kanban container into the DOM ──────────────

function injectKanbanElements() {
  // Find the RO tab's existing container
  var roTab = document.getElementById('tab-repairorders');
  if (!roTab) return;

  // Find the header area to add the toggle button
  var headerDiv = roTab.querySelector('.bg-brand-light');
  if (headerDiv) {
    var btnContainer = headerDiv.querySelector('.flex.items-center.gap-3');
    if (btnContainer) {
      // Check if button already exists
      if (!document.getElementById('ro-view-toggle')) {
        var toggleBtn = document.createElement('button');
        toggleBtn.id = 'ro-view-toggle';
        toggleBtn.className = 'bg-white/20 text-white px-4 py-2 rounded-lg text-sm hover:bg-white/30 flex items-center gap-1';
        toggleBtn.textContent = t('kanbanView', 'Kanban View');
        toggleBtn.addEventListener('click', function() {
          toggleKanbanView();
        });
        // Insert as the first button
        btnContainer.insertBefore(toggleBtn, btnContainer.firstChild);
      }
    }
  }

  // Wrap existing table + pagination in a container div if not already done
  var contentArea = roTab.querySelector('.bg-white.rounded-b-xl, .dark\\:bg-gray-800.rounded-b-xl');
  if (!contentArea) {
    // Fallback: find by structure
    var allDivs = roTab.querySelectorAll(':scope > div');
    if (allDivs.length >= 2) contentArea = allDivs[1];
  }
  if (!contentArea) return;

  if (!document.getElementById('ro-table-view')) {
    // Find the overflow-x-auto div (table wrapper) and pagination
    var tableWrapper = contentArea.querySelector('.overflow-x-auto');
    var pagination   = document.getElementById('ro-pagination');

    if (tableWrapper) {
      var tableViewDiv = document.createElement('div');
      tableViewDiv.id = 'ro-table-view';

      // Move table wrapper and pagination into the new container
      tableWrapper.parentNode.insertBefore(tableViewDiv, tableWrapper);
      tableViewDiv.appendChild(tableWrapper);
      if (pagination) {
        tableViewDiv.appendChild(pagination);
      }
    }
  }

  // Create kanban container if not present
  if (!document.getElementById('ro-kanban-view')) {
    var kanbanDiv = document.createElement('div');
    kanbanDiv.id = 'ro-kanban-view';
    kanbanDiv.style.display = 'none';

    var tableViewEl = document.getElementById('ro-table-view');
    if (tableViewEl) {
      tableViewEl.parentNode.insertBefore(kanbanDiv, tableViewEl.nextSibling);
    } else {
      contentArea.appendChild(kanbanDiv);
    }
  }
}

// ─── Init on DOM ready ───────────────────────────────────────────────────────

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectKanbanElements);
} else {
  injectKanbanElements();
}

})();
